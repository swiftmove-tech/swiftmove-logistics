import React from 'react';
function App() { return <h1>Welcome to SwiftMove Logistics</h1>; }
export default App;